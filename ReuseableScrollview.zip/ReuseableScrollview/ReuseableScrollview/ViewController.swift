//
//  ViewController.swift
//  ReuseableScrollview
//
//  Created by  on 16/8/13.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

/*
 原理：UIScrollView在大部分情况下，用for循环往里面直接塞
 UIImageView就OK了。但是如果需要展示的图片非常多，比如十张，几
 十张，甚至上百张，直接往UIScrollView里面塞上百的UIImageView
 肯定是行不通的。明显需要优化。UIScrollView在不滚动的时候，只会
 有一张图出现在视野中，滚动的时候同一时刻也最多只会有两张图出现在
 视野中。既然同一时刻最多只会有两张图在视野中，那么也既
 是同一时刻我们需要的imageView最多只要两个就够了，其他的就算添加
 到了scrollView中也看不到。（UITableview的重用机制也是这样）
 */

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate
{

    
    var scrollview:UIScrollView!
    //保存可见的imageview
    var VisibleImageViews:NSMutableSet!=NSMutableSet()
    //保存可重用的imageview
    var ReusedImageViews:NSMutableSet!=NSMutableSet()
    //图片名称数组
    var imageNames:NSMutableArray!=NSMutableArray()
    
    /*
     根据以上分析，可以建立容器reusedImageViews来存放可以
     重用的imageView，建立容器visibleImageViews来存放在
     可见范围内的imageView。
     */
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 0..<5
        {
            let str = String(format:"img%d.png",i%5)
            imageNames.addObject(str)
        }
        
        Generate_ScrollView()
        
    }
    

    
    func Generate_ScrollView()  {
        
        self.scrollview=UIScrollView.init(frame:self.view.bounds)
        self.scrollview.delegate=self
        self.scrollview.pagingEnabled=true
        self.scrollview.showsVerticalScrollIndicator=false
        self.scrollview.showsHorizontalScrollIndicator=false
        self.scrollview.contentSize = CGSizeMake((CGFloat)(self.imageNames.count) * self.view.bounds.size.width, 0)
        self.view.addSubview(self.scrollview)
        /*
         当scrollview第一次出现的时候,首先需要在屏幕中显示一张图片
         将imageview添加到scrollView.
         然后将它添加到VisibleImageViews进行保存.
         */
        ShowImageViewAtIndex(0)  //显示第一张照片
    }
    
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
        ShowImage()
        Test()
    }
    
    /*
     一张图->两张图
     如果向左滑动，会出现两张图的情况，视图2也需要加入显示，
     当开始滑动的那一刻,1.到reusedImageViews中查找可重
     用的imageView，如果没找到，则新建一个。假设得到的是视图2。
     将视图2添加到visibleImageViews进行保存，如果视图2是在
     reusedImageViews中找到的(不是新建的)，那么需要将视图2
     从reusedImageViews中移除。相当于将视图2从reusedImageViews
     移动到了visibleImageViews。将视图2添加到scrollView中，并进
     行一些个性设置，比如位置，图片等。
     */
    
    /*
     两张图->一张图
     
     如果继续像左滑动，直到视图1看不见的那一刻，也做三件事。
     
     视图1调用removeFromSuperview从scrollView中移除.
     将视图1放进reusedImageViews中等待被重用
     将视图1从visibleImageViews中移除，因为它已经属于reusedImageViews了。
     */
    
    /*
     如果再继续滑动，则又回到了一张图->两张图的情况，以此类推，
     利用重用进行优化的目的就达到了。以下是测试输出(不包含垂直
     和水平的滚动条)，通过子视图地址和子视图个数可以看到，无论
     怎么滚动，scrollView中只会存在两个imageView。
     */
    
    func ShowImage() {
        
        let bounds:CGRect = self.scrollview.bounds
        let minX:CGFloat = CGRectGetMinX(bounds)
        let maxX:CGFloat = CGRectGetMaxX(bounds)
        let width = CGRectGetWidth(bounds);
        
        var first_index:NSInteger = (NSInteger)(minX / width)
        var last_index:NSInteger = (NSInteger)(maxX / width)
        
        if(first_index<0)
        {
            first_index=0
        }
        
        if(last_index>=self.imageNames.count)
        {
           last_index=self.imageNames.count-1
        }
        
//        print("\(first_index)-\(last_index)")
        
        
        
        var index:NSInteger=0
        
        for imageview in self.VisibleImageViews
        
        {
           index = imageview.tag
            
            // 不在显示范围内
            if(index<first_index || index>last_index)
            {
                self.ReusedImageViews.addObject(imageview)
                imageview.removeFromSuperview()
            }
        }
        
        //minusSet,求差集,所有属于A且不属于B的元素构成的集合
        self.VisibleImageViews.minusSet(self.ReusedImageViews as Set<NSObject>)
        
        // 是否需要显示新的视图
        for INDEX in first_index...last_index
        {
            var isShow:Bool=false
            
            for imgv in self.VisibleImageViews
            {
               if imgv.tag==INDEX
               {
                   isShow=true
               }
            }
            
            if(!isShow)
            {
//                print(INDEX)
                ShowImageViewAtIndex(INDEX)
            }
        }
    }
    
    func ShowImageViewAtIndex(index:NSInteger){
        
        var imageview:UIImageView? = self.ReusedImageViews.anyObject() as! UIImageView!
        if imageview != nil
        {
            self.ReusedImageViews.removeObject(imageview!)  //imageview在重用集合中，则移除。
        }
        else  //imageview不在重用集合，则创建
        {
            imageview = UIImageView()
            imageview?.contentMode=UIViewContentMode.ScaleAspectFit
        }
        
        
        
        let bounds:CGRect = self.scrollview.bounds
        var imgFrame:CGRect = bounds
        
        //计算imageview显示的位置
        imgFrame.origin.x = CGRectGetWidth(bounds) * CGFloat(index)
        
        imageview?.frame=imgFrame
        imageview?.tag=index
        imageview?.image=UIImage.init(named:self.imageNames[index] as! String)
        [self.VisibleImageViews .addObject(imageview!)];  //imageview正显示，则将imageview添加进VisibleImageViews
        self.scrollview.addSubview(imageview!)
    }
    
    /*
      打印scrollview上所有imageview的内存地址发现
      只会存在2个地址块（图在末尾），实现了重用。
     */
    func Test()  {
       
        let str:NSMutableString = NSMutableString()
        
        let count:NSInteger = self.scrollview.subviews.count
        for imageview in self.scrollview.subviews
        {
           str.appendFormat("%p - ", imageview)
        }
        str.appendFormat("%ld", count)
        
        print(str)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

